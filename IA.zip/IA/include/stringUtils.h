#pragma once
#include <string>

class StringUtils {
  public:
    static bool isStringNumber(std::string str);
};